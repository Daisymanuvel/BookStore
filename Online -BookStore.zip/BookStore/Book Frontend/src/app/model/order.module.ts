export class Order {
  orderId: number=0;
  totalquantity:number=0;
  totalPrice:number=0;
  orderStatus: string='';
  paymentStatus: string='';
  orderedDate:string='';
  cartId: number=0;
  user: any;
  // Add other fields as necessary
}
